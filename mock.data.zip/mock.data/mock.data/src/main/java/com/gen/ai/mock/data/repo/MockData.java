package com.gen.ai.mock.data.repo;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;

@Data
@Builder
public class MockData {
    @Id
    private String id;
    private String serviceName;
    private String method;
    private Object mockData;
}
