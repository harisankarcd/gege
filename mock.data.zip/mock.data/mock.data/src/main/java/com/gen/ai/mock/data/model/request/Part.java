package com.gen.ai.mock.data.model.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Part {
    private String text;
}
