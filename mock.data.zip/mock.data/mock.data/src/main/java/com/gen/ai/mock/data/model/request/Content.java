package com.gen.ai.mock.data.model.request;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Content {
    private List<Part> parts;
}
