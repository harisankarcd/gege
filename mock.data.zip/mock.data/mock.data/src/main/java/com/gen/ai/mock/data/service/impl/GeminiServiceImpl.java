package com.gen.ai.mock.data.service.impl;

import com.gen.ai.mock.data.model.request.Content;
import com.gen.ai.mock.data.model.request.GenerateContentRequest;
import com.gen.ai.mock.data.model.request.Part;
import com.gen.ai.mock.data.service.client.GeminiClient;
import com.gen.ai.mock.data.service.service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class GeminiServiceImpl implements GeminiService {
    @Autowired
    GeminiClient geminiClient;
    public Object geminiCall(String primaryPrompt, String secPrompt, String swaggerInput){
        String prompt=((Objects.isNull(primaryPrompt)||primaryPrompt.isEmpty()) ?"You're tasked with creating a script or function to convert a Swagger schema into a JSON object for integration into your application. Your objective is to develop a flexible and reusable solution that can handle various Swagger schemas for this schema with the specified format and type":primaryPrompt)+ swaggerInput +((Objects.isNull(secPrompt)||secPrompt.isEmpty())?"":"with respect to"+secPrompt);
        List<Part> parts=new ArrayList<>();
        parts.add(Part.builder().text(prompt).build());
        List<Content> contents=new ArrayList<>();
        contents.add(Content.builder().parts(parts).build());
        return geminiClient.generateContent(GenerateContentRequest.builder().contents(contents).build());
    }
}
