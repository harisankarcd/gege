package com.gen.ai.mock.data.service.service;

import com.gen.ai.mock.data.service.client.GeminiClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public interface GeminiService {
}
