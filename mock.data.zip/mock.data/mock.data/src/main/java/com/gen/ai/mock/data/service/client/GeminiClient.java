package com.gen.ai.mock.data.service.client;

import com.gen.ai.mock.data.model.request.GenerateContentRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service
@FeignClient(value = "gemurl",url = "https://generativelanguage.googleapis.com")
public interface GeminiClient {
    @PostMapping("/v1beta/models/gemini-pro:generateContent?key=AIzaSyCfh3juO-GUq6E1_pWzWwl3vdmz2tS7hhc")
    Object generateContent(@RequestBody GenerateContentRequest request);
}
