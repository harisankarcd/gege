package com.gen.ai.mock.data.controller;

import com.gen.ai.mock.data.service.impl.GeminiServiceImpl;
import com.gen.ai.mock.data.service.impl.SaveMockImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@Slf4j
@RestController
@RequestMapping("/mock/")
public class MockDataController {
    @Autowired
    GeminiServiceImpl geminiService;
    @Autowired
    SaveMockImpl saveMock;

    @PostMapping("generate")
    public Object generateMockData(@RequestHeader(required = false) String primaryPrompt, @RequestHeader(required = false) String secPrompt, @RequestBody(required = true) String swaggerInput) {
        log.info("calling gemini Service");
        return geminiService.geminiCall(primaryPrompt,secPrompt,swaggerInput);
    }
    @PostMapping("save")
    public Object saveMockData(@RequestHeader String serviceName,@RequestHeader String method,@RequestBody Object mockData) {
        log.info("saving mock");
        return saveMock.saveMock(serviceName,method,mockData);
    }
}
