package com.gen.ai.mock.data.service.impl;

import com.gen.ai.mock.data.repo.MockData;
import com.gen.ai.mock.data.repo.MockRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SaveMockImpl {
    @Autowired
    MockRepo mockRepo;
    public String saveMock(String serviceName, String method, Object mockData){
        mockRepo.save(MockData.builder().mockData(mockData).serviceName(serviceName).method(method).build());
        return  "success";
    }
}
