package com.gen.ai.mock.data.repo;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
@Document("mock-data")
public interface MockRepo extends MongoRepository<MockData,String> {
}
